package com.innoventes.test.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InnotentesSpringbootTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(InnotentesSpringbootTestApplication.class, args);
	}

}
