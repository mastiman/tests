package com.innoventes.test.app.exception;

public interface AbstractError {

}
