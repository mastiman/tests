package com.innoventes.test.app.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Length;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EntityListeners(AuditingEntityListener.class)
@Table(name = "company")
@Entity
public class Company extends BaseEntity {

	@Id
	@SequenceGenerator(sequenceName = "company_seq", allocationSize = 1, name = "company_seq")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "company_seq")
	private Long id;

	@Column(name = "company_name")
	@NotBlank(message = "Company Name is mandatory")
	@Length(min=5)
	private String companyName;

	@Column(name = "email")
	@NotBlank(message = "E-mail is mandatory")
	@Email(regexp = "[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}")
	private String email;
	
	@Column(name = "strength")
	@Min(value=0 , message= "Strength should be greater than 0")
	private Integer strength;
	
	@Column(name = "website_url")
	private String webSiteURL;
	
	@Column(length = 5 , unique = true ,name = "company_code")
	@Pattern(regexp = "[a-z]{2}+[0-9]{2}+{E,N}", flags=Pattern.Flag.CASE_INSENSITIVE)
	private String company_code;


	public Long getId() {
		return this.id;
		
	}


	public void setId(Long id2) {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
	
	
	
}
